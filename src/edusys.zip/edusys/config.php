<?php
    $hostName = "localhost";
    $userName = "root";
    $password = "";
    $dbName = "edu_db";
    $baseName = "http://localhost/php/edusys/";
?>